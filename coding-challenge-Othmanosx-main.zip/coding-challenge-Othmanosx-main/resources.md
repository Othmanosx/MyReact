#Add the resources you used to answer the questions below:
   ex resource: https://stackoverflow.com/questions/9346954/doctype-html-what-does-it-mean
